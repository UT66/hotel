<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact</title>
</head>
<body>
<center>
    <div>
        <nav>
        <img src="img\logo.png" width="120" height="80">
            <div>
                <a class="link" href="index.php">Home</a>
                <a class="link" href="klant.php">Reserveren</a>
                <a class="link" href="contact-page.php">Contact</a>
                <a class="link" href="login.php">Login</a>
            </div>
        </nav>
    </div>
    </center>
     <div>
    <center>
        <section>
            <!--Hoofd tekst-->
            <h2>Neem gerust contact met ons op</h2>
            <!--contact info-->
                <div>
                    <ul>
                        <p>Van walbeeckstraat 95, 1058 CM, Amsterdam</p>
                        <p>020 1234 4567</p>
                        <p>hotel@info.nl</p>
                    </ul>
                </div>
            </div>
        </section>
</center>
    </div>
</body>

</html>