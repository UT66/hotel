<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home</title>
     <center>
    <div>
        <nav>
        <img src="img\logo.png" width="120" height="80">
            <div>
                <a class="link" href="index.php">Home</a>
                <a class="link" href="contact-page.php">Contact</a>
                <a class="link" href="login.php">Login</a>
            </div>
        </nav>
    </div>
    </center>
</head>
<body>
    <center>
        <div>
            <h1>Welkom bij ons hotel</h1>
            <p>Klik op reserveren om een kamer te boeken. voor meer infomatie gaan naar onze contact pagina.</p>
            <a href="klant.php">Reserveren</a>
        </div>
    </center>
    </body>
</html>